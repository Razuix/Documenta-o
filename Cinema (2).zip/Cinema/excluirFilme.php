<?php
    include "conexao.php";

    if(isset($_GET['id'])){

        $id = $_GET['id'];
        
        $sql = "delete from filmes where id = '$id'";
        $excluir = mysqli_query($conexao,$sql);

        //saida - feedback ao usuário
        if($excluir){
            echo "
                <script>
                    alert('Usuário exluido com Sucesso');
                    window.location = 'listarFilmes.php';
                </script>
            ";
            //header("location: listarUsuario.php");
        }
        else{
            echo "
                <p> Bando de Dados temporariamente fora do ar. Tente novamente mais tarde. </p>
                <p> Entre em contato com o administrador do Site</p>
            ";
            echo mysqli_error($conexao);
        }
    }
include "footer.php"
    
?>