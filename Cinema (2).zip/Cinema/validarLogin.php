<?php
    include "conexao.php";

    if(isset($_POST['usuario'])){
      

            $usuario = trim($_POST['usuario']);   
            $senha = trim($_POST['senha']);   
      

        $sql = "select * from usuario where usuario ='$usuario' and senha = '$senha'";
        $testeLogin = mysqli_query($conexao,$sql);
        $existe = mysqli_num_rows($testeLogin);

        if($existe){
            $dados = mysqli_fetch_array($testeLogin);
            $usuario = $dados['usuario'];
            $nivel = $dados['nivel'];
            
        
            if(!isset($_SESSION)){
                session_start();
            }
            $_SESSION['usuario'] = $usuario;
            $_SESSION['nivel'] = $nivel;
           

            if ($nivel == 'adm'){
                header('location: adm.php');
            }
            else{
                header('location: index.php');
            }
        }
        else{
            echo "Usuário e senha inválidos.";
        }
    }
    

?>