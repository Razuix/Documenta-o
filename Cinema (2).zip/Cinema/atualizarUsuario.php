<?php

    include "conexao.php";
    include "controle2.php";
    
    if(isset($_POST['usuario'])){
        //entrada - coletar os dados do formulário
        $usuario = trim($_POST['usuario']);
        $nivel = trim($_POST['nivel']);
        
        

        //processamento - incluir no banco de dados
        $sql = "update usuario set nome = '$usuario', nivel = '$nivel' where usuario = '$usuario'";
        $alterar = mysqli_query($conexao,$sql);

        //saida - feedback ao usuário
        if($alterar){
            echo "
                <script>
                    alert('Usuario Atualizado com sucesso!');
                    window.location = 'index.php';
                </script>
            ";
        }
        else{
            echo "
                <p> Sistema temporariamente fora do ar. Tente novamente mais tarde. </p>
                <p> Entre em contato com o administrador do Sistema. </p>
            ";
            echo mysqli_error($conexao);
        }
    }
    else{
        echo "
        <p style='color: white';> Esta é uma página de tratamento de dados. </p>
        <p style='color: white';> Clique <a href='login.php'>aqui</a> para fazer o login. </p>
        <p style='color: white';> Caso não tenha login, clique <a href='cadastro.php'>aqui</a> para fazer o cadastro.</p>
    ";  
    }

?>