<?php
include "controle.php"
?>
<h2 style="color: white; text-align:center; font-size:3em;"><b>Conheça nossos planos de fidelidade</b></h2>
<div>
    <img class="center" src="imagens/Informacoes-Clube.jpg" style="width:70%">
</div>
<div>
    <img class="center2" src="imagens/Banner-Rodapé-Produtos-Serviços-Fidelidade-2048x705.png" style="width:70%">
</div>

<?php
include "footer.php"
?>