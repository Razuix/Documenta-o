<?php
    if(!isset($_SESSION)){
        session_start();
    }
    if(!isset($_SESSION['usuario'])){
        echo "
            <script>
                alert('Área Restrita a usuário logados. Informe o seu Usuário e Senha');
                window.location = 'login.php';
            </script>
        ";
    }
    else{
        $nivel = $_SESSION['nivel'];
        $usuario = $_SESSION['usuario'];
        if($nivel != 'adm'){
            echo "
                <script>
                    alert('$usuario, Área Restrita a Administradores.');
                    window.location = 'index.php';
                </script>
        ";
        }
            
    }
?>