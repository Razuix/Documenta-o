<?php
include "controle.php"
?>
<h3 style="color: white; text-align:center; font-size:3em;">Alugue nossas salas</h3>
<div class="card mb-3 mx-auto" style="width: 50%;">
  <img class="card-img-top" src="imagens/13600_B289E4DB5A63F6C3-3.png" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title" style="text-align: center;">Sala Imax</h5>
    <p class="card-text">Sala Imax com a melhor qualidade de imagem e som</p>
  </div>
</div>
<div class="card mb-3 mx-auto" style="width: 50%;">
  <img class="card-img-top" src="https://s2.glbimg.com/8hCQoTjriy4nhu_lHK9GAsNdFOw=/0x0:2000x1324/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_59edd422c0c84a879bd37670ae4f538a/internal_photos/bs/2020/H/x/ehn1LTTZO4TUXZuM3x4A/kerala-coronavirus2.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title" style="text-align: center;">Sala Tradicional</h5>
    <p class="card-text">Sala Tradicional qualidade de imagem e som que cabem no seu bolso</p>
    
  </div>
</div>
<div class="card mb-3 mx-auto" style="width: 50%;">
  <img class="card-img-top" src="https://disneyplusbrasil.com.br/wp-content/uploads/2020/10/AMC-sala-de-cinema-1024x586.jpg" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title" style="text-align: center;">Sala Premium</h5>
    <p class="card-text">Nossa sala premium, que reúne qualidade de imagem e som com todo o luxo e conforto que você precisa</p>
    <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
  </div>
</div>

<?php
include "footer.php"
?>