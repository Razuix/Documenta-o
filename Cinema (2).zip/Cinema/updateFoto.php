<?php
    include "controle.php";
    include "conexao.php";
    if(isset($_POST['id'])){
        $id = trim($_POST['id']);

        //recebendo os arquivos de imagem
       $id= $_FILES ['foto'] ['id']; 
       $temp= $_FILES ['foto'] ['tmp_name']; 
       $caminho = '../filmes';
       $foto = $caminho . $id;

        //update de imagem
        $upload = move_uploaded_file($temp,$foto);

       if($upload){
           $sql = "update filmes set foto = '$foto'
           where id = '$id'";
           $alterar = mysqli_query($conexao,$sql);  
 
            if ($alterar) {
                echo"
                <script>
                alert('foto Atualizada com sucesso!');
                window.location = 'listarFilmes.php';
                </script>
                "; 
            }
            else{
                "<p>Sistema Temporariamente fora do ar 
                tente novamente mais tarde</p>
                <p>entre em contato com o administrador 
                do sistema</p>
                ";
                echo mysqli_error($conexao);
            }
       }
    }
  else{
      echo"
      <P>Esta é uma pagina de tratamento de dados</P>
      <p> Clique <a href='listarFilmes.php'>aqui para selecionar um usuário</a></p>
      ";
  }
    include "footer.php";
?>