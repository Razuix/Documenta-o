<?php
include "controle.php"
?>
<h4 style="color: white; text-align:center; font-size:3em;">Nossa localização mais próxima de você</h4>
<div class="mapa">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14702.943334633777!2d-43.2833283!3d-22.8862149!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x25151e5195671fe3!2sNorteShopping!5e0!3m2!1spt-BR!2sbr!4v1663768992594!5m2!1spt-BR!2sbr" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</div>
<?php
include "footer.php"
?>